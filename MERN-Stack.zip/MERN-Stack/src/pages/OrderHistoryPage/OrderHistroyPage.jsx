export default function OrderHistoryPage() {
  return <h2>OrderHistoryPage</h2>;
}
