export default function NewOrderPage() {
  return <h2>NewOrderPage</h2>;
}
