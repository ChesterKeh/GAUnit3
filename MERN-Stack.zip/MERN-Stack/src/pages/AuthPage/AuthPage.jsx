import SignUpForm from "../../components/SignUpForm/SignUpForm";

export default function AuthPage() {
  return (
    <>
      <h2>AuthPage</h2>
      <SignUpForm />
    </>
  );
}
